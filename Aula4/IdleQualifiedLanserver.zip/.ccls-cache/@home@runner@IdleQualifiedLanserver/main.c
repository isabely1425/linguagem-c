#include <stdio.h>
#include <math.h> 

int main() {
  float a, b, c;

  //Entrada de dados 
  printf("Digite o valor de a: ");
  scanf("%f", &a);

  printf("Digite o valor de b: ");
  scanf("%f", &b);

  // Cálculo do valor a 
  a = sqrt
  
  return 0;
}