#include <stdio.h>

// Fazendo a multiplicação de dois números 
int main() {
  // Declarando as variáveis 
  float num1, num2, mult;

  printf("Digite o primeiro número:  ");
  scanf("%f", &num1);

  printf("Digite o segundo número: ");
  scanf("%f", &num2); 

  // Calculo do vivisao
  mult = num1 * num2;

  // Saida do resoltado 
  printf("O resultado da multiplicação é: %f\n", mult);

  return 0;
}                                   